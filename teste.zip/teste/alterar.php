<!DOCTYPE html>
<html>
	<head>
    <meta charset="UTF-8">	
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Sistemas de Eventos</title>
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link href="css/bootstrap-theme.css" rel="stylesheet">
        <link rel="icon" href="imagens/logo.png">
	</head>	
	<body>
		<h1 class="table text-center">Alterar Evento</h1>
		<hr>
			
		<?php
		if (isset($_POST['btnAlt'])) {
			include('conexao.php');
			
			$id = $_POST['id'];
			$nome = $_POST['nome'];
            $hora = $_POST['hora'];
			
			//Executando o comando de alteração no Banco de dados
			
			$conn->query("UPDATE evento SET nome = '$nome', hora = '$hora' WHERE id = '$id'");
			
			echo '<h3>Dados Alterados com Sucesso!</h3>';
			
		
		}
		
		if(isset($_GET['id'])){
			//Estabelecendo a conexão com o banco de dados
			include('conexao.php');
			
			//Obetendo o RGM a partir da URL alterar 
			$id = $_GET['id'];
			
			$res = $conn->query("SELECT * FROM evento WHERE id='$id'");
			$linha = $res->fetch_assoc();
			
			$nome = $linha['nome'];
            $hora = $linha['hora'];
			
		}
		
		?>
		 <div class="table text-center">
		    <form action="alterar.php" method="post">
                    <input type="hidden" name="id" value="<?php echo $id; ?>"><br>
			        NOME: <input type="text" name="nome" value="<?php echo $nome; ?>"><br>
                    DATA DO EVENTO: <input type="text" name="hora" value="<?php echo $hora; ?>"><br>
			        <br><input type="submit" name = "btnAlt" value="Alterar Evento">
		    </form>
        </div><br><br><br>
		
		<div class="table text-center">
			<a href ="administrativo.php">
				<button class="btn btn-primary">VOLTAR</button>
			</a>
		<div>
		
	</body>
</html>	