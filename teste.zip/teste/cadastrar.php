<!DOCTYPE html>
<html>
	<head>
    <meta charset="UTF-8">	
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Sistemas de Eventos</title>
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link href="css/bootstrap-theme.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="css/estilo.css">
        <link rel="icon" href="imagens/logo.png">
	</head>	
	<body>
		<center>
            <h1 class="table text-center">Cadastrar Evento</h1>
		    <hr>
            <div id="bodyy">
                <center>
                    <BR>
                    <BR>

        <div class="col-8 m-auto">
            <form action="cadastrar.php" method="post">
			    ID: <input type="text" name="id"><br>
			    NOME: <input type="text" name="nome"><br>
                DATA: <input type="date" name="hora"><br>
			<input type="submit" name = "btnCad" value="Cadastrar">
		</form>
		</div>

		<?php
		if (isset($_POST['btnCad'])) {
			include('conexao.php');
			
			$id = $_POST['id'];
			$nome = $_POST['nome']; 
			$hora = $_POST['hora']; 
			//Executando o comando de inserçao no Banco de dados
			
			$conn->query("INSERT INTO evento VALUES('$id','$nome','$hora')");
			
			echo '<h3>Dados Cadastrados com Sucesso!</h3>';
			
		}
			
		?>
		
		<br><br><br>
        
        <div class="table text-center">
			<a href ="administrativo.php">
				<button class="btn btn-primary">VOLTAR</button>
			</a>
		<div>
    </center>
		
	</body>
</html>	