<?php
	session_start();
	echo "Usuario: ". $_SESSION['usuarioNome'];	
?>
<br>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">	
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Sistemas de Eventos</title>
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="icon" href="imagens/logo.png">
	</head>	
	<body>
		<h1 class="table text-center">Lista de Eventos</h1>
		<hr><br><br>
		
		<div class="text-center mt-3 mb-4">
		<a href="cadastrar.php">
        		<button class="btn btn-success">Cadastrar Evento</button>
      		</a>
 		 </div><br>	


		<div class="col-8 m-auto">
			<table border='1' class="table text-center">
			<thead class="thead-dark">
				<tr>
					<th>ID</th>
					<th>NOME DO EVENTO</th>
					<th>DATA E HORA</th>
					<th colspan="2">CONTROLES</th>
				</tr>
				</thead>
			<?php include('conexao.php'); 
			$res = $conn->query("SELECT * FROM evento");
			?>
			
			<?php while($linha = $res->fetch_assoc()) {?>
			<tr>
				<td><?php echo $linha['id']; ?></td>
				<td><?php echo $linha['nome']; ?></td>
				<td><?php echo $linha['hora']; ?></td>
				<td><a href="alterar.php?id=<?php echo $linha ['id']; ?> "><button class="btn btn-dark">Alterar</button></a></td>
				<td><a href="excluir.php?id=<?php echo $linha ['id']; ?> "><button class="btn btn-dark">Excluir</button></a></td>
			</tr>
			<?php  }  ?>
		</table>
		</div><br><br><br>	
		
		<div class="table text-center">
			<a href ="index.php">
				<button class="btn btn-danger">Sair</button>
			</a>
		<div>
	</body>
</html>
