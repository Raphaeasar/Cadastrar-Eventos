<!DOCTYPE html>
<html>
	<head>
    <meta charset="UTF-8">	
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Confirmar Exclusão de Eventos</title>
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link href="css/bootstrap-theme.css" rel="stylesheet">
        <link rel="icon" href="imagens/logo.png">
	</head>	
	<body>
		<h1 class="table text-center">Confirmar Exclusão de Eventos</h1>
		<hr>
			
		<?php
		if(isset($_GET['id'])){
			//Estabelecendo a conexão com o banco de dados
			include('conexao.php');
			
			//Obetendo o ID a partir da URL alterar 
			$id = $_GET['id'];
			
			$res = $conn->query("SELECT * FROM evento WHERE id='$id'");
			$linha = $res->fetch_assoc();
			
			echo 'ID: ' . $linha['id'] . '<br>';
			echo 'NOME: ' . $linha['nome'] . '<br>';
            echo 'DATA E HORA: ' . $linha['hora'] . '<br>';
			
		}
		
		if (isset($_POST['btnDel'])) {
			include('conexao.php');
			
			//Obtendo o valor no campo "hidden"
			$id = $_POST['id'];
			
			
			//Executando o comando de alteração no Banco de dados
			
			$conn->query("DELETE FROM evento WHERE id = '$id'");
			
			
            echo '<h3 >Dados Excluidos com Sucesso!</h3>';
			echo '<a href="administrativo.php">VOLTAR</a>';
			exit();
		
		}
		
		?>
		
		<div class="table text-center">
        <form action="excluir.php" method="post">
			<input type="text" name="id" value="<?php echo $_GET['id']; ?>"><br><br><br>
			<input type="submit" name = "btnDel" value="Deletar Evento">
		</form>
		<div><br><br><br>

		<div class="table text-center">
			<a href ="administrativo.php">
				<button class="btn btn-primary">VOLTAR</button>
			</a>
		<div>
		
	</body>
</html>	