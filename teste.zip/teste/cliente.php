<?php
	session_start();
	echo "Usuario: ". $_SESSION['usuarioNome'];	
?>
<br>

<!DOCTYPE html>
<html>
	<head>
		<title>Sistemas de Eventos</title>
		<meta charset="UTF-8">
		<link rel="icon" href="imagens/logo.png">
	</head>	
	<body>
		<center><h1>Lista de Eventos</h1>
		<hr><br><br>
		
		<table border=1">
			<tr>
				<th>ID</th>
				<th>NOME DO EVENTO</th>
				<th>E-MAIl</th>
				<th colspan="2">CONTROLES</th>
			</tr>
			<?php include('conexao.php'); 
			$res = $conn->query("SELECT * FROM evento");
			?>
			
			<?php while($linha = $res->fetch_assoc()) {?>
			<tr>
				<td><?php echo $linha['id']; ?></td>
				<td><?php echo $linha['nome']; ?></td>
				<td><a href="alterar.php?id=<?php echo $linha ['id']; ?> ">Alterar</a></td>
				<td><a href="excluir.php?id=<?php echo $linha ['id']; ?> ">Excluir</a></td>
			</tr>
			<?php  }  ?>
		</table><br>	
		<a href ="index.php">VOLTAR</a></center>
	</body>
</html>
<a href="sair.php">Sair</a>